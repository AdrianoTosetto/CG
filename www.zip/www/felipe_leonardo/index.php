<?php
	$con = new PDO('mysql:host=localhost;dbname=leonardo_felipe','root','');
?>
<html lang="pt-br">
<head>
	<title></title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="bootstrap-3.2.0-dist/css/bootstrap.css">
	<link rel="stylesheet" href="index.css">
	<script src="js/jquery.js"></script>
	<script>
	$(document).ready(function(){
	$('p').hide();
		$('a.s').click(function(){
			if($(this).next().css('display') == 'none'){
				$(this).next().slideDown();
				$(this).text("Esconder");
			}else{
				$(this).next().slideUp();
				$(this).text("Mostrar");
			}
		});
	});
	</script>
	<!--<link rel="stylesheet" href="bootstrap-3.2.0-dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="bootstrap-3.2.0-dist/css/bootstrap-theme.css">
	<link rel="stylesheet" href="bootstrap-3.2.0-dist/css/bootstrap-theme.min.css">-->
</head>
<body>
<div class="t">
	<header class="page-header"></header>
	<nav class="navbar navbar-default" role="navigation">
		<ul class="nav navbar-nav">
			<li class="active"><a href="index.php">Home</a></li>
			<li><a href="index.php">Sobre</a></li>
		</ul>
	</nav>
<div>
<?php
	$s = $con->query("SELECT * FROM jogos");
	$id = 0;
	while($r = $s->fetchObject()):
	$id++;
?>
	<div class="panel panel-default">
		<div class="panel-heading"><h3><?= $r->titulo;?></h3></div>
		<div class="panel-body">
			<img src="<?=utf8_encode($r->img);?>" height="370" width="370"/>
		</div>
		<div class="panel-footer"><a href="" id="<?=$id;?>" class="s" onclick="return false;">Mostrar</a><p class="desc"><?=$r->descricao;?></p></div>
	</div>
<?php endwhile;?>
</body>
</html>

