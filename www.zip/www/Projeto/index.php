<?php
	$con = new PDO('mysql:host=localhost;dbname=framework','root','');
?>
<html lang="pt-br">
<head>
	<title></title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" href="style.css">
</head>

<body>
<section id="all">
	<header class="page-header"></header>
	<div id="u-photo"></div>
	<nav id="u-nav">
		<ul id="u-menu">
			<li><a href="">Perfil</a></li>
			<li><a href="">Fotos</a></li>
			<li><a href="">Amigos</a></li>
			<li><a href="">Mensagens</a></li>
		</ul>
	</nav>
<div id="divisor"></div>
<section id="left"></section>
<section id="right"></section>
</section>
</body>
</html>