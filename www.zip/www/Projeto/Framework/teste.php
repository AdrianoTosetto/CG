<?php
	include 'DB.class.php';
	$fields = array('coluna1','coluna2','coluna3','coluna4');
	$values = "values";//array('valor1','valor2','valor3','valor4');
	DB::insertInto("framwork",$fields,$values);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	function array_string($array){
	$str="";
		for($i=0;$i<count($array);$i++){
			if($i > 0){
				$str = $str . ",".$array[$i];
			}else{
				$str = $array[$i];
			}
		}
		return $str;
	}
	//$e = array('a','b','c');
	//echo array_string($e);
?>