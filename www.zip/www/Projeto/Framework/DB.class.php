<?php
class DB{
	public static $dns;
	public static $root;
	public static $pass;
	public static $con;
	public static $sql;
	public static $fields;
	public static function connect($dns=null,$root=null,$pass=null){
		self::$dns  = $dns  == null?"mysql:host=localhost;dbname=framework":$dns;
		self::$root = $root == null?"root":$root;
		self::$pass = $pass == null?"":$pass;
		return new PDO(self::$dns,self::$root,self::$pass);
	}
	public static function insertInto($table,$fields,$values){
		self::$con = self::connect();
		self::$fields = "";
		if(is_array($fields)){
			for($i=0;$i<count($fields);$i++){
				if($i > 0){
					self::$fields = self::$fields . ",".$fields[$i];
				}else{
					self::$fields = $fields[$i];
				}
			}
		}
		$aux = self::$fields;
		self::$sql = "INSERT INTO $table($aux) VALUES('$values','$values','$values','$values')";
		//return self::$sql;
		return self::$con->prepare(self::$sql)->execute();
	}
}
?>