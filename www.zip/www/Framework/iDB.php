<?php
	interface iDB{
		static function connect($dns,$root,$pass);
		static function getFieldContent($table,$field);
		static function setFieldContent($table,$field);
		static function updateFieldContent($table,$field);
		static function deleteFieldContent($table,$field);
		static function getTableContent($table,$fields);
		static function setTableContent($table,$fields);
	}
?>