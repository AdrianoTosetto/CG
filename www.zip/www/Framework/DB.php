<?php
	//require 'iDB.php';
	class DB{
		const DNS  = "mysql:host=localhost;dbname=";
		const ROOT = "root";
		const PASS = "";
		public static $query;
		function __construct($dns,$root,$pass){connect($dns,$root,$pass);}
		
		public static function connect($dns,$root,$pass){
			return new PDO($dns,$root,$pass);
		} 
		static function getFieldContent($dns,$table,$field){
			$con = self::connect($dns,self::ROOT,self::PASS);
			if(!$con){exit;}
			return $con->query("SELECT $field FROM $table LIMIT 1")->fetch(PDO::FETCH_OBJ)->$field;
		}
		static function setFieldContent($dns,$table,$field,$str){}
		static function updateFieldContent($dns,$table,$field,$str){
			$con = self::connect($dns,self::ROOT,self::PASS);
			self::$query = "UPDATE $table set $field = '$str'";
			$aux = $con->prepare(self::$query);
			if($aux->execute()){
				return TRUE;
			}else{
				return FALSE;
			}
		}
		
		
		
		
		
		
		static function deleteFieldContent($table,$field){}
		static function getTableContent($table,$fields){}
		static function setTableContent($table,$fields){}
	}

?>