<?php
	require 'DB.php';
//	require 'iDB.php';
	echo DB::updateFieldContent("mysql:host=localhost;dbname=banco1","tabela1","nome1","jfk");
	echo DB::getFieldContent("mysql:host=localhost;dbname=banco1","tabela1","nome1");
	echo "\n<br>";
	echo (!TRUE && !!!FALSE) || null==null;
?>