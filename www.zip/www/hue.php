<?php
	echo (PDO::getAvailableDrivers());
?>