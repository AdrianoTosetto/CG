make clean
make
./exec
